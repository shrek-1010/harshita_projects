document.addEventListener("DOMContentLoaded", function () {
    console.log("Blood Bank Website Loaded");
});
